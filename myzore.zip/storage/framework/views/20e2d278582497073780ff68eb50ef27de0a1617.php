

<?php $__env->startSection('title', 'MyZore'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Crear serie de tallas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route'=>'admin.serieTallas.store']); ?>

<div class="row">
    <div class="card col-lg-6">
        <div class="card-header ">
            <h5><b>Serie</b></h5>
        </div>
        <div class="card-body ">

            <div class="form-group">
                <?php echo Form::label('linea_id','Linea'); ?>


                <?php echo Form::select('linea_id',$lineas,null,['class'=> 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('genero_id','Género'); ?>


                <?php echo Form::select('genero_id',$generos,null,['class'=> 'form-control']); ?>

            </div>
        </div>
    </div>

    <div class="card col-lg-5 ml-5">
        <div class="card-header ">
            <h5><b>Tallas</b></h5>
        </div>
        <div class="card-body ">
            <?php $__currentLoopData = $tallas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="input-group mb-1">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        <?php echo Form::checkbox('tallas[]', $talla->id,null); ?>

                    </span>
                </div>
                <input type="text" class="form-control" value=<?php echo e($talla->nombre); ?>>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
    </div>
</div>
<div class="row">
    <div class="card col-lg-12 pr-5">
        <div class="card-body">
            <div class="form-group">
                <?php echo Form::submit('Crear linea', ['class' => 'btn btn-primary float-right']); ?>

            </div>
        </div>

    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
<script>
    $(document).ready( function() {
        $("#nombre").stringToSlug({
            setEvents: 'keyup keydown blur',
            getPut: '#slug',
            space: '-'
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/serieTallas/create.blade.php ENDPATH**/ ?>