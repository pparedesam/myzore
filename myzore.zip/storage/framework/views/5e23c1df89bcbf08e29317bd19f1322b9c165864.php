

<?php $__env->startSection('title', 'MyZore'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Crear nuevo color</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php echo Form::open(['route'=>'admin.colores.store']); ?>

        <div class="form-group">
            <?php echo Form::label('nombre','Nombre'); ?>

            <?php echo Form::text('nombre',null,['class'=> 'form-control text-uppercase','placeholder'=>'Ingrese el nombre del color']); ?>


            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Crear color', ['class' => 'btn btn-primary float-right']); ?>

        </div>


        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/colores/create.blade.php ENDPATH**/ ?>