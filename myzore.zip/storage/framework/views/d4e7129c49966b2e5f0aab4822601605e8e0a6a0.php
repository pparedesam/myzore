

<?php $__env->startSection('title', 'MyZore'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Lista de proveedores</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('admin.providers.create')); ?>" class="btn btn-primary">Nuevo proveedor</a>
    </div>
    <div class="card-body">
        <table class="table table-striped " id="tblSocios">
            <thead>
                <tr>
                    <th class="text-center">Nro documento</th>
                    <th class="text-center">Apellido paterno</th>
                    <th class="text-center">Apellido materno</th>
                    <th class="text-center">Nombres</th>
                    <th class="text-center">Teléfono</th>
                    <th class="text-center">WhatsApp</th>
                    <th class="text-center">Fecha Nac.</th>
                    <th class="text-center">Estado civil</th>
                    <th class="text-center">Género</th>
                    <th class="text-center">Dirección</th>
                    <th class="text-center">Referencia</th>
                    <th class="text-center">Distrito</th>
                    <th class="text-center">Provincia</th>
                    <th class="text-center">Región</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $socios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(document).ready( function () {
        <?php if(session('info')): ?>
            Swal.fire(
                {icon: 'success',
                title: '<?php echo e(session('info')); ?>',
                showConfirmButton: true,
                timer: 3000
            });

        <?php endif; ?>
        $('#tblSocios').DataTable({
            "language":{
                "decimal":        "",
                "emptyTable":     "No hay registros",
                "info":           "Mostrando _START_ de _END_ de _TOTAL_ registros",
                "infoEmpty":      "Mostrando 0 de 0 de 0 registros",
                "infoFiltered":   "(filtrado de un total de _MAX_ registros.)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     "Mostrando _MENU_ registros",
                "loadingRecords": "cargando...",
                "processing":     "procesando...",
                "search":         "Buscar:",
                "zeroRecords":    "No se encontraron registros",
                "paginate": {
                    "first":      "Primero",
                    "last":       "Ultimo",
                    "next":       "Siguiente",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                }
            },
            destroy: true,
            responsive: true,
            autoWidth: false,
            ordering: false,
            "columns": [
                { width: "10%"},
                { width: "10%"},
                { width: "10%"},
                { width: "10%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "5%"},
                { width: "10%"},
            ]
            
        }
        
    );
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/socios/index.blade.php ENDPATH**/ ?>