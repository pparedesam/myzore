

<?php $__env->startSection('title', 'MyZore'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Lista de proveedores</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('admin.proveedores.create')); ?>" class="btn btn-primary">Nuevo proveedor</a>
    </div>
    <div class="card-body">
        <table class="table table-striped " id="tblProveedor">
            <thead>
                <tr>
                    <th class="text-center">RUC</th>
                    <th class="text-center">Razon Social</th>
                    <th class="text-center">Teléfono</th>
                    <th class="text-center">Dirección</th>
                    <th class="text-center">Distrito</th>
                    <th class="text-center">Provincia</th>
                    <th class="text-center">Región</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($proveedor->ruc); ?></td>
                    <td class="text-center"><?php echo e($proveedor->nombre); ?></td>
                    <td class="text-center"><?php echo e($proveedor->telefono); ?></td>
                    <td class="text-center"><?php echo e($proveedor->direccion); ?></td>
                    <td class="text-center"><?php echo e($proveedor->distrito->nombre); ?></td>
                    <td class="text-center"><?php echo e($proveedor->provincia->nombre); ?></td>
                    <td class="text-center"><?php echo e($proveedor->region->nombre); ?></td>
                    <td class="inline-block text-center">
                        <form action="<?php echo e(route('admin.proveedores.destroy',$proveedor)); ?>" method="post">
                            <a href="<?php echo e(route('admin.proveedores.edit',$proveedor)); ?>" class="btn btn-primary btn-sm mt-1">Editar</a>

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger btn-sm mt-1">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(document).ready( function () {
        <?php if(session('info')): ?>
            Swal.fire(
                {icon: 'success',
                title: '<?php echo e(session('info')); ?>',
                showConfirmButton: true,
                timer: 3000
            });

        <?php endif; ?>
        $('#tblProveedor').DataTable({
            "language":{
                "decimal":        "",
                "emptyTable":     "No hay registros",
                "info":           "Mostrando _START_ de _END_ de _TOTAL_ registros",
                "infoEmpty":      "Mostrando 0 de 0 de 0 registros",
                "infoFiltered":   "(filtrado de un total de _MAX_ registros.)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     "Mostrando _MENU_ registros",
                "loadingRecords": "cargando...",
                "processing":     "procesando...",
                "search":         "Buscar:",
                "zeroRecords":    "No se encontraron registros",
                "paginate": {
                    "first":      "Primero",
                    "last":       "Ultimo",
                    "next":       "Siguiente",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                }
            },
            destroy: true,
            responsive: true,
            autoWidth: false,
            ordering: false,
            "columns": [
                { width: "10%"},
                { width: "20%"},
                { width: "20%"},
                { width: "10%"},
                { width: "10%"},
                { width: "10%"},
                { width: "10%"},
                { width: "10%"},
            ]
            
        }
        
    );
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/proveedores/index.blade.php ENDPATH**/ ?>