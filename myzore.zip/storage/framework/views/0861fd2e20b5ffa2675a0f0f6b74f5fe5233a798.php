
<?php $__env->startSection('head'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'MyZore'); ?>


<?php $__env->startSection('content_header'); ?>
<h1>DETALLE DE KARDEX DE <?php echo e($producto->nombre); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card col-lg-12">
    <div class="card-header">
        <h4>Registrar nuevo movimiento</h4>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-6"></div>
            <div class="col-lg-6">
                <div class="form-group ">
                    <?php echo Form::label('linea','Linea'); ?>


                    <?php echo Form::text('linea',$producto->linea->nombre,['class'=> 'form-control text-uppercasecol-lg-12
                    text-center','placeholder'=>'Ingrese el nombre del almacen','autocomplete'=>'off','disabled']); ?>

                </div>
                <div class="form-group ">
                    <?php echo Form::label('genero','Género'); ?>


                    <?php echo Form::text('genero',$producto->genero->nombre,['class'=> 'form-control text-uppercasecol-lg-12
                    text-center','placeholder'=>'Ingrese el nombre del almacen','autocomplete'=>'off','disabled']); ?>

                </div>
                <div class="form-group ">
                    <?php echo Form::label('material','Material'); ?>


                    <?php echo Form::text('material',$producto->material->nombre,['class'=> 'form-control
                    text-uppercasecol-lg-12 text-center','placeholder'=>'Ingrese el nombre del
                    almacen','autocomplete'=>'off','disabled']); ?>

                </div>
                <div class="form-group ">
                    <?php echo Form::label('tipo','Tipo'); ?>


                    <?php echo Form::text('tipo',$producto->tipo->nombre,['class'=> 'form-control text-uppercasecol-lg-12
                    text-center','placeholder'=>'Ingrese el nombre del almacen','autocomplete'=>'off','disabled']); ?>

                </div>
                <div class="form-group ">
                    <?php echo Form::label('color','Color'); ?>


                    <?php echo Form::text('color',$color->nombre,['class'=> 'form-control text-uppercase
                    text-center','placeholder'=>'Ingrese el nombre del almacen','autocomplete'=>'off','disabled']); ?>

                </div>
            </div>
        </div>

    </div>
</div>

<?php echo Form::open(['route'=>'admin.kardexes.store']); ?>

<div class="card ">
    <div class="card-body">
        <div class="row">
            <div class="form-group col-lg-3">
                <?php echo Form::label('tipo_id','Tipo'); ?>

                <?php echo Form::text('producto_id',$producto->id,['hidden']); ?>

                <?php echo Form::text('color_id',$color->id,['hidden']); ?>

                <?php echo Form::select('tipo_id',$kardexTiposDetalle,null,['class'=> 'form-control']); ?>

            </div>
            <div class="form-group col-lg-9">
                <?php echo Form::label('motivo','Motivo'); ?>

                <?php echo Form::text('motivo',null,['class'=> 'form-control text-uppercase ','placeholder'=>'Ingrese un motivo','autocomplete'=>'off']); ?>

                <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <?php $__currentLoopData = $kardexes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kardex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <div class="input-group-text">
                    <?php echo Form::checkbox('kardexes[]', $kardex, $kardex->id, ['class'=> '','onclick'=>'return false']); ?>

                </div>
            </div>
            <input type="text" class="form-control col-2" readonly aria-label="" value=<?php echo e($kardex->nombreTalla); ?>>
            
            <input type="text" class="form-control text-center" name=<?php echo e($kardex->id); ?> aria-label="" value="0" onkeypress="return soloNumero(event, this);" onblur="soloNumero(event, this);">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="card ">
    <div class="card-body">
        <div class="row">
            <div class="form-group col-lg-6 offset-lg-3">
                <?php echo Form::submit('Registrar movimiento', ['class' => 'btn btn-primary float-right col-lg-12']); ?>

            </div>
        </div>

    </div>
</div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script>
    $(document).ready( function () {
        <?php if(session('info')): ?>
            Swal.fire(
                {icon: 'success',
                title: '<?php echo e(session('info')); ?>',
                showConfirmButton: true,
                timer: 3000
            });
        <?php endif; ?>

        <?php if(session('error')): ?>
            Swal.fire(
                {icon: 'error',
                title: '<?php echo e(session('error')); ?>',
                showConfirmButton: true,
                timer: 3000
            });
        <?php endif; ?>      
  
    } );

    $('#tblMovimientos').DataTable({
        "language":{
            "decimal":        "",
            "emptyTable":     "No hay registros",
            "info":           "Mostrando _START_ de _END_ de _TOTAL_ registros",
            "infoEmpty":      "Mostrando 0 de 0 de 0 registros",
            "infoFiltered":   "(filtrado de un total de _MAX_ registros.)",
            "infoPostFix":    "",
            "thousands":      ",",
            "lengthMenu":     "Mostrando _MENU_ registros",
            "loadingRecords": "cargando...",
            "processing":     "procesando...",
            "search":         "Buscar:",
            "zeroRecords":    "No se encontraron registros",
            "paginate": {
                "first":      "Primero",
                "last":       "Ultimo",
                "next":       "Siguiente",
                "previous":   "Anterior"
            },
        },
        destroy: true,
        responsive:true,
        autoWidth: false,
        "lengthChange": false,
        filter:true,
        "paging": true, 
        "bInfo": false,
        "pageLength": 5,
        ordering: false,
        "columns": [
            { width: "20%"},
            { width: "20%"},
            { width: "40%"},
            { width: "20%"},
        ],

        createdRow: function (row, data, indice) {
            $(row).find("td:eq(0)").attr('data-id', data.id);
            $(row).find("td:eq(0)").attr('data-index', indice);
        }
        
    });
    

    function orbtenerProvincias(region_id){
               
        $.get('/admin/Ubigeo/region/'+region_id+'/provincias',function(data){
            let html_select = '';
            for (let i=0; i<data.length;++i){
                html_select +='<option value="'+data[i].id+'">'+data[i].nombre+'</option>';
                if(i==0){
                    obtenerDistritos(data[i].id)
                }
            }     
            $('#provincia_id').html(html_select);
        })
        
    }

    function obtenerDistritos(provincia_id){

        $.get('/admin/Ubigeo/provincia/'+provincia_id+'/distritos',function(data){
            let html_select = '';
            for (let i=0; i<data.length;++i)
                html_select +='<option value="'+data[i].id+'">'+data[i].nombre+'</option>';
            $('#distrito_id').html(html_select);
        })
        
    }

    function soloNumero(e, input) {
        var key = window.Event ? e.which : e.keyCode

        if (input.value.length >= 4) {
            return false;
        } else {
            e.value = parseInt(e.value, 10);
            return ((key >= 48 && key <= 57));
        }
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/kardexes/edit.blade.php ENDPATH**/ ?>