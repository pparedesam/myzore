

<?php $__env->startSection('title', 'MyZore'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Serie de tallas</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="card">

    <div class="card-body">
        <table class="table table-striped" id="tblSeries">
            <thead>
                <tr>
                    <th class="text-center" data-priority="1">Línea</th>
                    <th class="text-center">Género</th>
                    <th class="text-center">Cantidad de tallas</th>
                    <th data-priority="1"></th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $seriesTallas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serietalla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                   
                    <td class="text-center"><?php echo e($serietalla->linea->nombre); ?></td>
                    <td class="text-center"><?php echo e($serietalla->genero->nombre); ?></td>
                    <td class="text-center">
                                            <?php echo e($serietalla->where('estado','1')
                                            ->where('linea_id',$serietalla->linea_id)
                                            ->where('genero_id',$serietalla->genero_id)
                                            ->count()); ?>

                    </td>

                    <td class="text-center">
                        <a href="<?php echo e(route('admin.serieTallas.edit',[$serietalla->linea,$serietalla->genero])); ?>" class="btn btn-primary btn-sm">Editar</a>
                        

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready( function () {
        <?php if(session('info')): ?>
            Swal.fire(
                {icon: 'success',
                title: '<?php echo e(session('info')); ?>',
                showConfirmButton: true,
                timer: 3000,
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            });

        <?php endif; ?>
        $('#tblSeries').DataTable({
            "language":{
                "decimal":        "",
                "emptyTable":     "No hay registros",
                "info":           "Mostrando _START_ de _END_ de _TOTAL_ registros",
                "infoEmpty":      "Mostrando 0 de 0 de 0 registros",
                "infoFiltered":   "(filtrado de un total de _MAX_ registros.)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     "Mostrando _MENU_ registros",
                "loadingRecords": "cargando...",
                "processing":     "procesando...",
                "search":         "Buscar:",
                "zeroRecords":    "No se encontraron registros",
                "paginate": {
                    "first":      "Primero",
                    "last":       "Ultimo",
                    "next":       "Siguiente",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                }
            },
            destroy: true,
            responsive: true,
            autoWidth: false,
            ordering: false,
            "columns": [
                { width: "30%"},
                { width: "30%"},
                { width: "30%"},
                { width: "10%"},
            ]
            
        }
        
    );
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/serieTallas/index.blade.php ENDPATH**/ ?>