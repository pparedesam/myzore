
<?php $__env->startSection('head'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'MyZore'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Crear nuevo almacen</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route'=>'admin.warehouses.store','id'=>'frmDatos','name'=>'frmDatos']); ?>

<div class="row">
    <div class="card col-lg-12">
        <div class="card-body">

            <div class="row">
                <div class="form-group col-lg-12">
                    <?php echo Form::label('nombre','Nombre'); ?>

                    <?php echo Form::text('nombre',null,['class'=> 'form-control text-uppercase
                    col-lg-12','placeholder'=>'Ingrese el nombre del almacen','autocomplete'=>'off']); ?>

                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-lg-4">

                    <?php echo Form::label('user_id','Responsable'); ?>


                    <?php echo Form::select('user_id',$users,null,['class'=> 'form-control']); ?>

                </div>
                <div class="form-group col-lg-8">
                    <?php echo Form::label('direccion','Dirección'); ?>

                    <?php echo Form::text('direccion',null,['class'=> 'form-control text-uppercase
                    col-lg-12','placeholder'=>'Ingrese una dirección para el almacen','autocomplete'=>'off']); ?>

                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
            <div class="row">
                <div class="form-group col-lg-4">

                    <?php echo Form::label('region_id','Región'); ?>


                    <?php echo Form::select('region_id',$regiones,null,['class'=> 'form-control']); ?>

                </div>
                <div class="form-group col-lg-4">

                    <?php echo Form::label('provincia_id','Provincia'); ?>


                    <?php echo Form::select('provincia_id',$provincias,null,['class'=> 'form-control']); ?>

                </div>
                <div class="form-group col-lg-4">

                    <?php echo Form::label('distrito_id','Distrito'); ?>


                    <?php echo Form::select('distrito_id',$distritos,null,['class'=> 'form-control']); ?>

                </div>
            </div>
            <hr/>
            <div class="form-group">
                <?php echo Form::submit('Crear almacen', ['class' => 'btn btn-primary float-right']); ?>

            </div>
        </div>
        
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    $("#region_id").change(function(){
        let region_id=$("#region_id").val();
        orbtenerProvincias(region_id)
    })

    $("#provincia_id").change(function(){
        let provincia_id=$("#provincia_id").val();
        obtenerDistritos(provincia_id)
    })

    function orbtenerProvincias(region_id){
               
        $.get('/admin/Ubigeo/region/'+region_id+'/provincias',function(data){
            let html_select = '';
            for (let i=0; i<data.length;++i){
                html_select +='<option value="'+data[i].id+'">'+data[i].nombre+'</option>';
                if(i==0){
                    obtenerDistritos(data[i].id)
                }
            }     
            $('#provincia_id').html(html_select);
        })
        
    }

    function obtenerDistritos(provincia_id){

        $.get('/admin/Ubigeo/provincia/'+provincia_id+'/distritos',function(data){
            let html_select = '';
            for (let i=0; i<data.length;++i)
                html_select +='<option value="'+data[i].id+'">'+data[i].nombre+'</option>';
            $('#distrito_id').html(html_select);
        })
        
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/warehouses/create.blade.php ENDPATH**/ ?>