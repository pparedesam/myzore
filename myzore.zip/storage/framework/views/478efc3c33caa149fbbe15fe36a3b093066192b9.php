<aside class="control-sidebar control-sidebar-<?php echo e(config('adminlte.right_sidebar_theme')); ?>">
    <?php echo $__env->yieldContent('right-sidebar'); ?>
</aside>
<?php /**PATH C:\www\myzore\resources\views/vendor/adminlte/partials/sidebar/right-sidebar.blade.php ENDPATH**/ ?>