

<?php $__env->startSection('title', 'MyZore'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Catálogos</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card col-lg-3 mr-4">
        <div class="card-header">
            <h3>Nuevo Catálogo</h3>
        </div>
        <div class="card-body">
            <?php echo Form::open(['route'=>'admin.catalogs.store']); ?>

            <div class="form-group">
                <?php echo Form::label('nombre','Campaña'); ?>

                <?php echo Form::text('nombre',null,['class'=> 'form-control text-uppercase','placeholder'=>'NOMBRE PARA LA CAMPAÑA']); ?>


                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('fechaInicio','Fecha inicio'); ?>

                <div class="" id="sandbox-container">
                    <div class="input-group date">
                        <?php echo Form::text('fechaInicio',null,['class'=> 'form-control text-center','placeholder'=>'FECHA DE INICIO','readonly']); ?>

                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                        </div>
                    </div>
                </div>
                <?php $__errorArgs = ['fechaInicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('fechaFin','Fecha fin'); ?>

                <div class="" id="sandbox-container">
                    <div class="input-group date">
                        <?php echo Form::text('fechaFin',null,['class'=> 'form-control text-center','placeholder'=>'FECHA DE FIN','readonly']); ?>

                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                        </div>
                    </div>
                </div>

                <?php $__errorArgs = ['fechaFin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group ">
                <?php echo Form::label('type_id','Tipo'); ?>


                <?php echo Form::select('type_id',$types,null,['class'=> 'form-control']); ?>

            </div>
            <hr>
            <div class="form-group">
                <?php echo Form::submit('Crear catalogo', ['class' => 'btn btn-primary float-right col-12']); ?>

            </div>


            <?php echo Form::close(); ?>

        </div>

    </div>
    <div class="card col-lg-8">
        <div class="card-header">
            <h3>Lista de catálogos</h3>
        </div>
        <div class="card-body">
            <table class="table table-striped" id="tblCatalogs">
                <thead>
                    <tr>
                        <th class="text-center">Campaña</th>
                        <th class="text-center">Fecha Inicio</th>
                        <th class="text-center">Fecha Fin</th>
                        <th class="text-center">Tipo</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($catalog->nombre); ?></td>
                        <td class="text-center"><?php echo e($catalog->fechaInicio); ?></td>
                        <td class="text-center"><?php echo e($catalog->fechaFin); ?></td>
                        <td class="text-center"><?php echo e($catalog->type->nombre); ?></td>
                        <td class="text-center">
                            <form action="<?php echo e(route('admin.catalogs.destroy',$catalog)); ?>" method="post">
                                <a href="<?php echo e(route('admin.catalogs.edit',$catalog)); ?>"
                                    class="btn btn-primary btn-sm mt-1 col-12">Editar</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger btn-sm mt-1 col-12">Eliminar</button>
                            </form>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready( function () {
        <?php if(session('info')): ?>
            Swal.fire(
                {icon: 'success',
                title: '<?php echo e(session('info')); ?>',
                showConfirmButton: true,
                timer: 3000,
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            });

        <?php endif; ?>        
    } );

    $('#tblCatalogs').DataTable({
        "language":{
            "decimal":        "",
            "emptyTable":     "No hay registros",
            "info":           "Mostrando _START_ de _END_ de _TOTAL_ registros",
            "infoEmpty":      "Mostrando 0 de 0 de 0 registros",
            "infoFiltered":   "(filtrado de un total de _MAX_ registros.)",
            "infoPostFix":    "",
            "thousands":      ",",
            "lengthMenu":     "Mostrando _MENU_ registros",
            "loadingRecords": "cargando...",
            "processing":     "procesando...",
            "search":         "Buscar:",
            "zeroRecords":    "No se encontraron registros",
            "paginate": {
                "first":      "Primero",
                "last":       "Ultimo",
                "next":       "Siguiente",
                "previous":   "Anterior"
            },
            "aria": {
                "sortAscending":  ": activate to sort column ascending",
                "sortDescending": ": activate to sort column descending"
            }
        },
        destroy: true,
        responsive: true,
        autoWidth: false,
        ordering: false,
        "columns": [
            { width: "30%"},
            { width: "20%"},
            { width: "20%"},
            { width: "20%"},
            { width: "10%"},
        ]
        
    });

    $('#sandbox-container .input-group.date').datepicker({
        format: "yyyy-mm-dd",
        maxViewMode: 0,
        todayBtn: "linked",
        language: "es",
        autoclose: true
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\myzore\resources\views/admin/catalogs/index.blade.php ENDPATH**/ ?>